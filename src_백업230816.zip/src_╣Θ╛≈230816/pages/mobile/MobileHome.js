import React from 'react'

export default function MobileHome() {
  return (
    <div>MobileHome</div>
  )
}
