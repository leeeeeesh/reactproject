import React from 'react'

export default function Event() {
  return (
    <div>Event</div>
  )
}
