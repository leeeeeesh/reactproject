import React from 'react'

export default function Clinic() {
  return (
    <div>Clinic</div>
  )
}
