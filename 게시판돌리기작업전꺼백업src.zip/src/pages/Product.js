import React from 'react'
import { Link } from 'react-router-dom'
import styles from './product.module.css'

export default function Product() {
  return (
    <>
      <div className='subvisual_wrap'>
        <section className='subvisual'>
          <h2>상품</h2>
        </section>
      </div>

      <div id={styles.product_wrap}>
        <section id={styles.product}>
          {/* <h2 className='hidden'>판매상품목록</h2> */}
          <h2 className='maintitle'>판매상품목록</h2>
          <ul id={styles.product_category}>
            <li>
              <Link className={styles.selected}>전체</Link>
            </li>

            <li>
              <Link>할인</Link>
            </li>
            
            <li>
              <Link>사료</Link>
            </li>
            
            <li>
              <Link>간식</Link>
            </li>
            
            <li>
              <Link>위생</Link>
            </li>
            
            <li>
              <Link>의약품</Link>
            </li>
          </ul>

          <ul id={styles.product_list}>

            <li>
              <Link to='/productdetail'>
                <div className={styles.product_list_img}>
                  <img src="./images/item00.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item01.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item02.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item03.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item04.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item05.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item06.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item07.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>
            
            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item00.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item01.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item02.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>

            <li>
              <Link>
                <div className={styles.product_list_img}>
                  <img src="./images/item03.jpg"/>
                </div>
                <p className={styles.product_list_category}>의약품</p>
                <p className={styles.product_list_title}>TITLETITLETITLETITLE</p>
                <p className={styles.product_list_text}>1,800원</p>
              </Link>
            </li>
            
          </ul>

          <div id={styles.product_btn_wrap}>
            <ul id={styles.product_num}>
              <li>
                <Link className={styles.selected}>1</Link>
              </li>
              <li>
                <Link>2</Link>
              </li>
              <li>
                <Link>3</Link>
              </li>
              <li>
                <Link>4</Link>
              </li>
              <li>
                <Link>5</Link>
              </li>
            </ul>
          </div>
        </section>
      </div>
    </>
  )
}
