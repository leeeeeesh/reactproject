import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useLocation, useParams } from 'react-router-dom'
import Count from '../components/count/Count'
import useProducts from '../hooks/useProducts'
import styles from './productdetail.module.css'
import regExp from '../util/regExp'

export default function ProductDetail() {

  // const {productId} = useParams()

  // const [allProduct] = useProducts()


  const [price, setPrice]=useState(1)

  const addPrice = ()=>{
    setPrice(price+1)
  }

  const removePrice = ()=>{
    setPrice(price-1)
  }

  const {productId} = useParams()

  const [allProduct] = useProducts()//직접만든 훅

  const [productItem, setProductItem] = useState([])

  useEffect(()=>{
    const productItem = allProduct.filter((item)=>(item.id===productId))
    setProductItem(productItem)
  },[allProduct])

  const {pathname} = useLocation()

  useEffect(()=>{
    window.scrollTo(0,0)
  },[pathname])


  return (
    <>
      <div className={`subvisual_wrap ${styles.detail_visual}`}>
        <section className='subvisual'>
          <h2>상품</h2>
          <p>인기 판매 상품을 확인해 보세요.</p>
        </section>
      </div>

      <div id={styles.detail_wrap}>
        {
          productItem.map((item)=>(
            <section id={styles.detail} key={item.id}>
              <h2 className='hidden'>상품 상세페이지</h2>
              <div id={styles.detail_img}>
                <img src={item.image}/>
              </div>

              <div id={styles.detail_buy}>
                <p className={`${styles.detail_best} ${item.isBest === true && styles.on}`}>BEST</p>
                <p className={styles.detail_category}>{item.category}</p>
                <p className={styles.detail_title}>{item.title}</p>
                <p className={styles.detail_price}>{regExp.comma(item.price*price)}<span>원</span></p>

                <div className={styles.detail_text}>
                  <p>{item.text}</p>
                </div>

                <div id={styles.buy_btn_wrap}>
                  <Count onAdd={addPrice} onRemove={removePrice}/>
                  <div id={styles.buy_btn}>
                    <button>구매하기</button>
                  </div>
                </div>
              </div>
            </section>
          ))
        }


        {/* <section id={styles.detail}>
          <h2 className='hidden'>상품 상세페이지</h2>
          <div id={styles.detail_img}>
            <img src='./images/item00.jpg'/>
          </div>

          <div id={styles.detail_buy}>
            <p className={styles.detail_category}>의약품</p>
            <p className={styles.detail_title}>TITLE TITLE TITLE</p>
            <p className={styles.detail_price}>1800<span>원</span></p>

            <div className={styles.detail_text}>
              <p>Text Text Text Text Text Text Text Text Text Text</p>
            </div>

            <div id={styles.buy_btn_wrap}>
              <Count onAdd={addPrice} onRemove={removePrice}/>
              <div id={styles.buy_btn}>
                <button>구매하기</button>
              </div>
            </div>
          </div>
        </section> */}
      </div>

      <div id={styles.detail_content_wrap}>
        <section id={styles.detail_content}></section>
      </div>
    </>
  )
}
