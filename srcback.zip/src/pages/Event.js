import React from 'react'
import Ready from '../components/ready/Ready'

export default function Event() {
  return (
    <>
      <Ready/>
    </>
  )
}
